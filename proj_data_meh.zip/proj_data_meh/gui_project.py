from tkinter import *
import tkinter.ttk as ttk 
from yal import *
from phase2 import *
from phase3 import *
from phase4 import *
import arabic_reshaper
from bidi.algorithm import get_display

def change(event, row, col,df): 
        # get value from Entry 
        value = event.widget.get() 
        # set value in dataframe 
        df.iloc[row,col] = value 
        print(df)
def prpeople():
    df = shakhs_csv
    for i in range(len(df)):
        x = arabic_reshaper.reshape(df['mahaletavalod'][i])
        l = get_display(x)
        df['mahaletavalod'][i] = l

        x = arabic_reshaper.reshape(df['mahalekar'][i])
        l = get_display(x)
        df['mahalekar'][i] = l
        
        x = arabic_reshaper.reshape(df['name'][i])
        l = get_display(x)
        df['name'][i] = l

        x = arabic_reshaper.reshape(df['familyname'][i])
        l = get_display(x)
        df['familyname'][i] = l
 
    # --- main --     
    
    rooot = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot.mainloop()
def praccounts():
    df = hesabbanki_csv
    for i in range(len(df)):
        x = arabic_reshaper.reshape(df['namebank'][i])
        l = get_display(x)
        df['namebank'][i] = l
 
    # --- main --     
    
    rooot = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot.mainloop()
def prcars():
    df = mashin_csv
    for i in range(len(df)):
        x = arabic_reshaper.reshape(df['model'][i])
        l = get_display(x)
        df['model'][i] = l
    for i in range(len(df)):
        x = arabic_reshaper.reshape(df['pelak'][i])
        l = get_display(x)
        df['pelak'][i] = l
 
    # --- main --     
    
    rooot = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot.mainloop()
def prhomes():
    df = khane_csv
    for i in range(len(df)):
        x = arabic_reshaper.reshape(df['addres'][i])
        l = get_display(x)
        df['addres'][i] = l
 
    # --- main --     
    
    rooot = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot.mainloop()
def prownerships():
    df = malekiat_csv
    for i in range(len(df)):
        x = arabic_reshaper.reshape(df['next'][i])
        l = get_display(x)
        df['next'][i] = l

 
    # --- main --     
    
    rooot = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot.mainloop()
def prtaransaction():
    df = tarakonesh_csv
 
    # --- main --     
    
    rooot = Tk()
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot.mainloop()
def prphones():
    df = hamrah_csv
    for i in range(len(df)):
        x = arabic_reshaper.reshape(df['operator'][i])
        l = get_display(x)
        df['operator'][i] = l

 
    # --- main --     
    
    rooot = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot.mainloop()
def prcalls():
    df = tamsa_csv

    # --- main --     
    
    rooot = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot.mainloop()
def prrelationships():
    df = family_csv

    # --- main --     
    
    rooot = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot.mainloop()
def printphase1():
    roott=Tk()
    roott.title("Phase 1")
    #root.geometry("500x300")
    roott["background"]="black"
    ld0=Label(roott,text="\t\t\t",bg="black",fg="red")
    ld0.grid(row=0,column=0)
    ld1=Label(roott,text="",bg="black",fg="red")
    ld1.grid(row=1,column=0)
    ld2=Label(roott,text="",bg="black",fg="red")
    ld2.grid(row=2,column=0)
    gbd=LabelFrame(roott,text="",bg="black",fg="red")
    gbd.grid(row=4,column=0)
    ld4=Label(roott,text="",bg="black",fg="red")
    ld4.grid(row=5,column=0)
    ld5=Label(roott,text="",bg="black",fg="red")
    ld5.grid(row=6,column=0)
    gbd1=LabelFrame(roott,bg="black",fg="red")
    gbd1.grid(row=7,column=0)
    ld6=Label(roott,text="",bg="black",fg="red")
    ld6.grid(row=8,column=0)

    bd1= Button(gbd,text="People", width=15,justify="center",bg="black",fg="red",command=prpeople)
    bd1.grid(row=0,column=0)
    bd2= Button(gbd,text="Accounts", width=15,justify="center",bg="black",fg="red",command=praccounts)
    bd2.grid(row=1,column=0)
    bd3= Button(gbd,text="Homes", width=15,justify="center",bg="black",fg="red",command=prhomes)
    bd3.grid(row=2,column=0)
    bd4= Button(gbd,text="Cars", width=15,justify="center",bg="black",fg="red",command=prcars)
    bd4.grid(row=3,column=0)
    bd5= Button(gbd,text="Phones", width=15,justify="center",bg="black",fg="red",command=prphones)
    bd5.grid(row=4,column=0)

    bd6= Button(gbd,text="Ownerships", width=15,justify="center",bg="black",fg="red",command=prownerships)
    bd6.grid(row=5,column=0)
    bd7= Button(gbd,text="Transactions", width=15,justify="center",bg="black",fg="red",command=prtaransaction)
    bd7.grid(row=6,column=0)
    bd8= Button(gbd,text="Calls", width=15,justify="center",bg="black",fg="red",command=prcalls)
    bd8.grid(row=7,column=0)  
    bd9= Button(gbd,text="Relationships", width=15,justify="center",bg="black",fg="red",command=prrelationships)
    bd9.grid(row=8,column=0)

    bd10= Button(gbd1,text=":)", width=6,bg="black",fg="red",font="armin 10 bold")
    bd10.grid(row=0,column=0)
    bd11= Button(gbd1,text="Back", width=6,bg="black",fg="red",command=roott.destroy)
    bd11.grid(row=0,column=1)
    roott.mainloop()
def printphase2():
    suspect_df = pd.DataFrame(suspect_name,columns =["Name"])
    for i in range(len(suspect_df)):
        x = arabic_reshaper.reshape(suspect_df['Name'][i])
        l = get_display(x)
        suspect_df['Name'][i] = l
    df = suspect_df

    # --- main --     
    
    rooot22 = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot22) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    rooot22.mainloop()    
    # start program 
        
def printphase3():
    for k,v in ravabet:
        tmp = []
        for i in v:
            tmp.append(shakhs.dic[i].name)
        ravabet_name[shakhs.dic[k].name]= tmp

    phase3_df = pd.DataFrame(ravabet_name,columns = ravabet_name.keys())

    df = phase3_df
    for i in range(len(df)):
        for j in df.columns:
            x = arabic_reshaper.reshape(df[j][i])
            l = get_display(x)
            df[j][i] = l
 
    # --- main --      
    
    rooot33 = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot33) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot33.mainloop()

def printphase4():
    for i in radtamas:
        tmp = []
        for j in i:
            tmp.append(shakhs.dic[j].name)
        radtamas_name.append(tmp)
    phase4_df = pd.DataFrame(radtamas_name , columns = ['from' , 'to' , 'time'])
    df=phase4_df
    for i in range(len(df)):
        for j in df.columns:
            x = arabic_reshaper.reshape(df[j][i])
            l = get_display(x)
            df[j][i] = l
 
    # --- main --      
    
    rooot44 = Tk() 
    
    # create entry for every element in dataframe 
    
    rows, cols = df.shape 
    
    for r in range(rows): 
        for c in range(cols): 
            e = Entry(rooot44) 
            e.insert(0, df.iloc[r,c]) 
            e.grid(row=r, column=c) 
            # ENTER  
            e.bind('<Return>', lambda event, y=r, x=c: change(event,y,x,df)) 
            # ENTER on keypad 
            e.bind('<KP_Enter>', lambda event, y=r, x=c: change(event,y,x,df)) 
    
    # start program 
    
    rooot44.mainloop()
def des():
    rroott=Tk()
    rroott.title("Description")
    rroott["background"]="black"
    gbb=LabelFrame(rroott,text="",bg="black",fg="red")
    gbb.grid(row=0,column=0)
    gbb1=LabelFrame(gbb,text="Introduction ",bg="black",fg="red")
    gbb1.grid(row=0,column=0)

    gbb3=LabelFrame(gbb1,text="Welcome",font="armin 8",bg="black",fg="red")
    gbb3.grid(row=1,column=0)
    ll1=Label(gbb3,text="""Welcome to the Simulator program.   
In this program we try to calculate   
the current of circuit  .
""",justify="left",bg="black",fg="red")
    ll1.grid(row=0,column=0)
    gbb4=LabelFrame(gbb1,text="Contact US ",font="armin 8",bg="black",fg="red")
    gbb4.grid(row=2,column=0)
    ll3=Label(gbb4,text="""You can use the following ways 
to reach us and provide your 
comments,criticisms,suggestions.
Telegram : @ArmiinJP
Email : Arminjp2000@gmail.com


""",justify="left",bg="black",fg="red")
    ll3.grid()



    gbb2=LabelFrame(gbb,text="How to use :",bg="black",fg="red")
    gbb2.grid(row=0,column=1)
    ll2=Label(gbb2,text="""


*** In the open window on the left, the number of resistors is first
specified in the first field. *** Then the value of the resistors has to
be determined; its format is,for example: 0,1,2 *** In the next field
the number of voltage sources is specifiedand. *** andin the last field
the value of these voltage sources is specified,and their format is
similar to the Top format. *** Finally, if the number of values is not equal
to the number entered,you will encounter an error "Please enter correctly"
*** Or if you don't even enter one of the values you will get an
error "Please enter Values" *** Otherwise, the current value of the circuit will
be displayed in the new window ***. :\n\n\n""",justify="left",font="armin 10",bg="black",fg="red")
    ll2.grid(row=0,column=0)

    gbb5=LabelFrame(gbb1,text="",bg="black",fg="red")
    gbb5.grid(row=3,column=0)
    bb1=Button(gbb5,text="Back",width=11,height=1,bg="black",fg="red",command=rroott.destroy)
    bb1.grid(row=0,column=0)
    bb2=Button(gbb5,text="Exit",width=11,height=1,bg="black",fg="red",command=exit)
    bb2.grid(row=0,column=1)
    rroott.mainloop()
    

root = Tk()
root.title("Edge of Darkness")
#root.geometry("500x300")
root["background"]="black"
p=PhotoImage(file="Snímka-obrazovky-2019-04-08-o-17.22.22.png")
l0=Label(image=p)
l0.grid(row=0,column=0)
gb=LabelFrame(text="",bg="black",fg="red")
gb.grid(row=1,column=0)
#l6=Label(gb,text="welcome",font="armin",fg="white",bg="white")
#l6.grid(row=0,column=0)

b1= Button(gb,text="Phase 1", width=12,bg="black",fg="red",command=printphase1)
b1.grid(row=0,column=0)
b2= Button(gb,text="Phase 2", width=12,bg="black",fg="red",command=printphase2)
b2.grid(row=0,column=1)
b3= Button(gb,text="Phase 3", width=12,bg="black",fg="red",command=printphase3)
b3.grid(row=0,column=2)
b4= Button(gb,text="Phase 4", width=12,bg="black",fg="red",command=printphase4)
b4.grid(row=0,column=3)
l1=Label(gb,text="\t\t",bg="black",fg="red")
l1.grid(row=0,column=4)
b5= Button(gb,text="Help", width=12,bg="black",fg="red",command=des)
b5.grid(row=0,column=5)
b6= Button(gb,text="Exit", width=12,bg="black",fg="red",command=root.destroy)
b6.grid(row=0,column=6)



root.mainloop()
